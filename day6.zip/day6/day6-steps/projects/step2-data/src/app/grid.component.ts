import { Component, Input} from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-grid',
  template: `
  <h1>Version Number : {{ ver }}</h1>
  <table class="table table-sm">
    <thead class="thead-dark">
      <tr>
        <th> Sl # </th>
        <th> Title </th>
        <th> Place </th>
        <th> Full Name </th>
        <th> Ticket Price </th>
        <th> Poster </th>
        <th> Release Date </th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of heroes?.data">
        <td> {{ hero.sl }} </td>
        <td> {{ hero.title | uppercase | lowercase | titlecase }} </td>
        <td> {{ hero.city | slice : 0 : 5 }} </td>
        <td> {{ hero.firstname+" "+hero.lastname }} </td>
        <td> {{ hero.ticketprice | currency : 'INR' : 'code' : '3.2-3' }} </td>
        <td> 
          <img width="50" [src]="hero.poster" alt="{{ hero.name }}">
        </td>
        <td>{{ hero.releasedate | date : 'dd / MMMM / yyyy' }}</td>
      </tr>
    </tbody>
  </table>
  `,
  styles: [
  ]
})
export class GridComponent{
    // @Input('compdata') heroes = []
    /*
    */
    heroes ;
    ver = 0;

    // STEP 1

    // constructor(private hs:HeroService){
    //     this.heroes = this.hs.getHeroData();
    //     this.ver = this.hs.getVersion();
    // }

    // STEP 2
    constructor(private hs:HeroService){
        this.hs.getHeroData().subscribe((res) => {
          this.heroes = res;
        });
        this.ver = this.hs.getVersion();
    }

   // @Input('compdata') heroes = [];
   // @Input('compver') ver = 0;
    // hs:HeroService;
    // constructor(){
    //     this.hs = new HeroService();
    //     this.heroes = this.hs.getHeroData();
    //     this.ver = this.hs.getVersion();
    // }

}
