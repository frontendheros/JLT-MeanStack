import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template : `
  <app-header></app-header>
  <app-grid></app-grid>
  `
})
export class AppComponent {
  title = 'step3-pipes';
  appdata = [];
  appver = 0;

  constructor(private hs:HeroService){
    this.appdata = this.hs.getHeroData();
    this.appver = this.hs.getVersion();
  }
}
