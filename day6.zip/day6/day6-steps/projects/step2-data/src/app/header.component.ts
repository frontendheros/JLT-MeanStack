import { Component, Input, OnInit } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
  <h1>Version Number : {{ ver }}</h1>
  <ul class="nav justify-content-center">
    <li *ngFor="let hero of heroes?.data">
      <a class="nav-link" href="#">{{ hero.title }}</a>
    </li>
  </ul>
  `,
  styles: [
  ]
})
export class HeaderComponent{
 // @Input('compdata') heroes = []
 // @Input('compdata') heroes = [];
 // @Input('compver') ver = 0;
    // hs:HeroService;
    // constructor(){
    //     this.hs = new HeroService();
    //     this.heroes = this.hs.getHeroData();
    //     this.ver = this.hs.getVersion();
    // }

    heroes;
    ver = 0;

    constructor(private hs:HeroService){
        // this.heroes = this.hs.getHeroData();
        this.hs.getHeroData().subscribe( (res) =>{
            this.heroes = res;
        })
        this.ver = this.hs.getVersion();
    }

}
