import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1 innerHTML={{title}}></h1>
  <button (click)="clickHandler()">Click Me</button>
  <h2>Message from Child Comp : {{ childMessage }} </h2>
  <hr>
  <app-child (childEvent)="clickHandler($event)" ct="hello child">
     <h1> Heading 1 </h1>
     <h2> Heading 2 </h2>
     <h3> Heading 3 </h3>
     <h4> Heading 4 </h4>
     <h5 class="box"> Heading 5 </h5>
     <p>
       Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias blanditiis, eveniet reprehenderit, neque ullam mollitia quam ducimus architecto odio exercitationem provident similique quidem. Qui enim dicta sed sapiente accusantium alias.
       Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias blanditiis, eveniet reprehenderit, neque ullam mollitia quam ducimus architecto odio exercitationem provident similique quidem. Qui enim dicta sed sapiente accusantium alias.
     </p>
     <span class="player">List Item</span>
     <br>
     <em class="player">List Item</em>
     <br>
     <strong class="player">List Item</strong>
     <br>
     <cite class="player">List Item</cite>
  </app-child>
  `,
})
export class AppComponent {
  title = 'Welcome to your life';
  childMessage = "default message";
  clickHandler(evt){
    // alert("message : "+evt)
    this.childMessage = evt.uname+" | "+evt.upass;
  }
}
// h${ Heading $ }