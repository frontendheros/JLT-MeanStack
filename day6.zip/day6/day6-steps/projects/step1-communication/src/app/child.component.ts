import { Component, EventEmitter, Input, Output } from "@angular/core";

// inputs : ['childTitle'],
@Component({
    selector : "app-child",
    template : `
    <div class="childbox">
        <h1>Hello From Child Component</h1>
        <ul>
            <li><ng-content select=".box"></ng-content></li>
            <li><ng-content select="p"></ng-content></li>
            <li><ng-content select="h3"></ng-content></li>
            <li><ng-content select="h4"></ng-content></li>
            <li><ng-content select="h2"></ng-content></li>
            <li><ng-content select="h1"></ng-content></li>
        </ul>
        <ng-content select=".player"></ng-content>
        <h1>{{ childTitle }}</h1>
        <input #ti1 type="text">
        <input #ti2 type="password">
        <button (click)="emitHandler({uname : ti1.value, upass:ti2.value})">Click to Emit</button>
    </div>
    `,    
    styles : [`
    .childbox{
      width : 600px;
      padding : 10px;
      background-color : silver
    }
    `]
})
export class ChildComp{
    @Input('ct') childTitle = "default value";
    @Output() childEvent:EventEmitter<any> = new EventEmitter();
    message = "hello parent";

    // constructor(){
    //     setTimeout(() => {
    //         this.childEvent.emit();
    //     }, 3000 )
    // }

    emitHandler(arg){
        this.childEvent.emit(arg);
    }
}