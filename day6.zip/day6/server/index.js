const express = require("express");
const cors = require("cors");
const data = require("./data/heroes.json");
//----------------------------------------
let app = express();
    app.use(cors());
//----------------------------------------
app.get("/", function(req, res){
    res.json(data)
});
//----------------------------------------
app.listen(1010, "localhost", function(error){
    if(error){
        console.log("Error ", error)
    }else{
        console.log("Web server is now live on localhost:1010")
    }
})