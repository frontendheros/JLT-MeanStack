import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  
  `
})
export class AppComponent {
  title = 'day7-steps';
}
