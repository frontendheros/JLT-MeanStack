import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>Template Form</h1> 
  <app-templateform></app-templateform>
  
  <h1>Reactive Form</h1> 
  <app-dataform></app-dataform>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-forms';
}
