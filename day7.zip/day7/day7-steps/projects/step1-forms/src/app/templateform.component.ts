import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-templateform',
  template: `
    <form action="#" (submit)="formSubmitHandler(myForm, $event)" #myForm="ngForm" name="myform" novalidate method="get">
      <label for="username"> User Name </label>
      <input type="text" #userName="ngModel" id="username" [(ngModel)]="uname" required name="username" />
      <br/>
      <label for="useremail"> User eMail </label>
      <input type="text" #userMail="ngModel" id="useremail" [(ngModel)]="uemail" required 
      name="useremail" pattern=".+@.+" />
      <span *ngIf="userMail.invalid && userMail.touched"> Invalid Email id </span>
      <br/>
      <label for="userage"> User Age </label>
      <input type="text" #userAge="ngModel" id="userage" [(ngModel)]="uage" required name="userage" />
      {{ userageerror }}
      <br/>
      <button type="submit"> Login </button>
    </form>
    <hr>
    <p>User Name: {{ uname }}</p>
    <p>User eMail: {{ uemail }}</p>
    <p>User Age: {{ uage }}</p>
    <p *ngIf="userMail.untouched"> User eMail is Untouched </p>
    <p *ngIf="userMail.touched"> User eMail is Touched </p>
    <p *ngIf="userMail.pristine"> User eMail is Pristine </p>
    <p *ngIf="userMail.dirty"> User eMail is Dirty </p>
    <p *ngIf="userMail.valid"> User eMail is Valid </p>
    <p *ngIf="userMail.invalid"> User eMail is Invalid </p>
  `,
  styles: [`
    label, input {
      width : 150px;
      display : block;
      padding : 5px;
      margin : 5px
    }
    input.ng-valid.ng-touched{
      border : 5px solid darkgreen
    }
    input.ng-invalid.ng-touched{
      border : 5px solid crimson
    }
    button { 
      margin : 5px;
      width : 140px;
      height : 50px;
    }
  `]
})
export class TemplateformComponent implements OnInit {
  uname = '';
  uemail = '';
  uage = 0;
  userageerror = ''; 

  constructor() { }

  formSubmitHandler( form:NgForm, evt){
    evt.preventDefault();
    if(form.controls.userage.value < 18){
      this.userageerror = "you are too young to join us";
    }else if(form.controls.userage.value > 80) {
      this.userageerror = "you are too old to join us";
    }else{
      this.userageerror = "";
      evt.target.submit();
    }
  }

  ngOnInit(): void {
  }

}
