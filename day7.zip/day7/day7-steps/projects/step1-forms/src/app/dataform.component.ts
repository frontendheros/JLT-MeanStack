import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dataform',
  template: `
    <form [formGroup]="userForm" (ngSubmit)="submitHandler($event)" novalidate >
      <label for="username"> User Name </label>
      <input id="username" formControlName="username"  />
      <br/>
      <label for="useremail"> User eMail </label>
      <input required formControlName="useremail" />
      <span *ngIf="userForm.get('useremail').invalid"> Invalid Email id </span>
      <br/>
      <label for="userage"> User Age </label>
      <input required formControlName="userage" />
      <br/>
      <button type="submit"> Login </button>
      </form>
      <button (click)="fillNameHandler()" type="submit"> Fill only Name </button>
      <br>
      <button (click)="fillFormHandler()" type="submit"> Fill all data </button>
    <hr>
    <p>User Name: {{ userForm.get('username').value }}</p>
    <p>User eMail: {{ userForm.get('useremail').value }}</p>
    <p>User Age: {{ userForm.get('useremail').value }}</p>
    <p *ngIf="userForm.get('useremail').untouched"> User eMail is Untouched </p>
    <p *ngIf="userForm.get('useremail').touched"> User eMail is Touched </p>
    <p *ngIf="userForm.get('useremail').pristine"> User eMail is Pristine </p>
    <p *ngIf="userForm.get('useremail').dirty"> User eMail is Dirty </p>
    <p *ngIf="userForm.get('useremail').valid"> User eMail is Valid </p>
    <p *ngIf="userForm.get('useremail').invalid"> User eMail is Invalid </p>
  `,
  styles: [`
    label, input {
      width : 150px;
      display : block;
      padding : 5px;
      margin : 5px
    }
    input.ng-valid.ng-touched{
      border : 5px solid darkgreen
    }
    input.ng-invalid.ng-touched{
      border : 5px solid crimson
    }
    button { 
      margin : 5px;
      width : 140px;
      height : 50px;
    }
  `]
})
export class DataformComponent implements OnInit {
  userForm:FormGroup;
  constructor( private fb:FormBuilder ) { }


  fillNameHandler(){
    this.userForm.patchValue({
        username : 'Batman'
    })
  }
  fillFormHandler(){
    this.userForm.setValue({
        username : 'Bruce',
        useremail : 'bruce@waynefoundation.com',
        userage : '25'

    })
  }

  ngOnInit(){
       this.userForm = this.fb.group({
           username : ['', Validators.required ],
           useremail : [ '', Validators.pattern('.+@.+')],
           userage : ['0']
       }) 
  }
  submitHandler(evt){
      console.log(evt)
      console.log("+++++++++++++++")
      console.log(this.userForm.controls.username.value)
  }
}
