import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <h1> Default Page for products  </h1>
  `,
  styles: [
  ]
})
export class DefaultProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
