import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movies',
  template: `
    <h1> Movies works! </h1>
    <h2>Quantity : {{ quantity }}</h2>
  `,
  styles: [
  ]
})
export class MoviesComponent implements OnInit {

  quantity = 0

  constructor( private actRoute:ActivatedRoute ) { }

  ngOnInit(): void {
    // this.quantity = this.actRoute.snapshot.params['qty'];
    this.actRoute.params.subscribe( val => {
      this.quantity = val['qty'];
    })
  }

}
