import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1>Hello Routing</h1>
  <ul>
  <li> <a class="link" routerLinkActive="selectedList"  [routerLinkActiveOptions]="{ exact : true }" [routerLink]="['']"> Home </a> </li>
  <li> <a class="link" routerLinkActive="selectedList"  [routerLink]="['about']"> About </a> </li>
  <li> <a class="link" routerLinkActive="selectedList"  [routerLink]="links"> Product </a> </li>
  <li> <a class="link" routerLinkActive="selectedList"  [routerLink]="['contact']"> Contact </a> </li>
  <li> <a class="link" routerLinkActive="selectedList"  [routerLink]="['anyother']"> Any other </a> </li>
  </ul>
  <hr/>
  <router-outlet></router-outlet>
  `,
  styles : [`
    .link{
      color : black;
      width : 100px;
      height : 20px;
      display : inline-block;
      margin : 5px;
      text-align : center;
      text-decoration : none
    }
    .selectedList{
      background-color : crimson;
      color : white
    }
  `]
})
export class AppComponent {
  title = 'ng-steps';
  productType = 'movies';
  links = ['product'];
}

/*

<ul>
    <li> <a href=""> Home </a> </li>
    <li> <a href="about"> About </a> </li>
    <li> <a href="product"> Product </a> </li>
    <li> <a href="contact"> Contact </a> </li>
    <li> <a href="anyother"> Any other </a> </li>
  </ul>
  <hr/>
  <ul>
  <li> <a routerLink=""> Home </a> </li>
  <li> <a routerLink="about"> About </a> </li>
  <li> <a routerLink="product"> Product </a> </li>
  <li> <a routerLink="contact"> Contact </a> </li>
  <li> <a routerLink="anyother"> Any other </a> </li>
  </ul>
  <hr/>
*/