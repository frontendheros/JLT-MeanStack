import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  template: `
  <h1>
    Contact Page
  </h1>
  `,
  styles: [
  ]
})
export class ContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
