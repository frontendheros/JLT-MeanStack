import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gifts',
  template: `
    <h1>
      gifts works!
    </h1>
  `,
  styles: [
  ]
})
export class GiftsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
