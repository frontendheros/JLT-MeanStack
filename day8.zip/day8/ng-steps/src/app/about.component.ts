import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
  <h1>
    About Page
  </h1>
  `,
  styles: [
  ]
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
