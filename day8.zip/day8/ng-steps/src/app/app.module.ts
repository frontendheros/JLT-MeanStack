import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { AboutComponent } from './about.component';
import { ProductComponent } from './product.component';
import { ContactComponent } from './contact.component';
import { NotfoundComponent } from './notfound.component';

import { DefaultProductComponent } from './defaultProduct.component';
import { MoviesComponent } from './movies.component';
import { GiftsComponent } from './gifts.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ProductComponent,
    ContactComponent,
    NotfoundComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot([
      { path : '',         component : HomeComponent },
      { path : 'about',    component : AboutComponent },
      { path : 'product', component : ProductComponent,
       children : [
          { path : '', component : DefaultProductComponent },
          { path : 'movies/:qty', component : MoviesComponent },
          { path : 'gifts', component : GiftsComponent },
      ] },
      { path : 'contact',  component : ContactComponent },
      { path : '**',       component : NotfoundComponent },
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
