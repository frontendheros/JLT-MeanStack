import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product',
  template: `
  <h1> Product Page </h1>
    <ul>
      <li> <a [routerLink]="['movies',imdb]"> Movies </a> </li>
      <li> <a [routerLink]="['gifts']"> Gifts </a> </li>
    </ul>
    <input type="range" #rng (input)="imdb = rng.value" >{{ imdb }}
  <hr>
  <router-outlet></router-outlet>
  `,
  styles: [
  ]
})
export class ProductComponent {
  imdb = 0;
 // constructor( private actRoute:ActivatedRoute ) { }

  // ngOnInit(): void {
  //   this.productType = this.actRoute.snapshot.params['type']
  // }

}
