import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DefaultProductComponent } from './defaultProduct.component';
import { GiftsComponent } from './gifts.component';
import { MoviesComponent } from './movies.component';

@NgModule({
declarations : [ MoviesComponent, GiftsComponent ],
imports : [ RouterModule.forChild([
    { path:'' ,                  component: DefaultProductComponent},
    { path:'product/movies' ,    component: MoviesComponent},
    { path:'product/gifts' ,     component: GiftsComponent},
])],
exports : [ MoviesComponent, GiftsComponent ]
})
export class ProductModule{

}