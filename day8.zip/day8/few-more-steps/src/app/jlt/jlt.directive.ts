import { Directive, ElementRef, Input, OnInit } from '@angular/core';

// selector : 'jlt' // will be used as tag directive
// selector : '[jlt]' // will be used as attribute directive
// selector : '.jlt' // will be used as class directive

@Directive({
    selector : '[jlt]'
})
export class JLTDirective implements OnInit{
    @Input('jlt') tagname = 'blue';
    constructor( private elRef : ElementRef){ };
    ngOnInit(){
        /*
        let tempInnerHTML = this.elRef.nativeElement.innerHTML;
        this.elRef.nativeElement.outerHTML = "<"+this.tagname+">"+tempInnerHTML+"</"+this.tagname+">";
        */
      let tempInnerHTML = this.elRef.nativeElement.innerHTML;
      this.elRef.nativeElement.outerHTML = "<h1 style='background-color: "+this.tagname+"'>"+tempInnerHTML+"</h1>";
    }
}