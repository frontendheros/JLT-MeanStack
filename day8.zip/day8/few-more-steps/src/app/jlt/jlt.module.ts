import { NgModule } from '@angular/core';
import { JLTDirective } from './jlt.directive';
import { JLTPipe } from './jlt.pipe';
import { JLTComp } from './jlt.component';

@NgModule({
    declarations : [JLTDirective, JLTPipe, JLTComp],
    exports : [JLTDirective, JLTPipe, JLTComp]
})
export class JLTModule{

}