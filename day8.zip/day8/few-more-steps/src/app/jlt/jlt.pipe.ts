import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'jlt'
})
export class JLTPipe implements PipeTransform{
    transform(){
        return 'JLT Says '+arguments[1]+': '+arguments[0];
    }
}