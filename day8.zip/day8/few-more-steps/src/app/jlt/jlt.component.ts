import { Component } from "@angular/core";

@Component({
    selector : 'app-jltcomp',
    template : `
    <h1>{{ title }}</h1>
    `
})
export class JLTComp{
    title = "Welcome to JLT Component"
}