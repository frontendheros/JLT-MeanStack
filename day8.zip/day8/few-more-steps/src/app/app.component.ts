import { Component } from '@angular/core';
import { AsyncData } from './asyncService';

@Component({
  selector: 'app-root',
  template : `
  <h1>Hello there</h1>
  <h2> Promise Data : {{ serviceData | async }}</h2>
  <p jlt="yellow"> Paragraph 1   </p>
  <p> {{ title | jlt : 'hi'}} </p>
  <p> {{ title | jlt : 'hello'}} </p>
  <p> {{ title | jlt : 'ola'}} </p>
  <p> {{ title | jlt : 'namaskar'}} </p>
  <p jlt="red"> Paragraph 3 </p>
  <p> Paragraph 4 </p>
  `
})
export class AppComponent {
  title = 'few-more-steps';
  serviceData;
  constructor( private ad:AsyncData){
      this.serviceData = this.ad.getAsyncPromise();
  }
}
