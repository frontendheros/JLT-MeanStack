import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AsyncData } from './asyncService'
import { JLTModule } from './jlt/jlt.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule, JLTModule
  ],
  providers: [ AsyncData ],
  bootstrap: [AppComponent]
})
export class AppModule { }
