export class AsyncData{
    getAsyncPromise(){
        return new Promise(function(resolve , reject){
                setTimeout(function(){
                    resolve("Data from Promise Resolved")
                }, 5000)
        })
    }
}