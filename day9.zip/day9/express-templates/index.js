const express = require("express");
const bodyParser = require("body-parser");

const app = express();
// Middleware
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded());
let list = ["Batman", "Ironman", "Phantom", "Antman"];

app.get("/", function(request, response){
    response.render("homePug.pug",{
        compname : "JLT Pune",
        herolist : list
    });
    //console.log("in the home page");
    // next();
});
app.get("/product/:qty", function(request, response){
    response.send("<h1> Welcome to Products page of JLT </h1><h2> Quantity : "+request.params.qty+"</h2>")
});
app.post("/", function(request, response){
    console.log(request.body.heroname);
    list.push(request.body.heroname);
    response.redirect('/');
    response.end();
});
app.get("/contact", function(request, response){
    response.send("<h1> Contact JLT </h1>")
});
app.get("*", function(request, response){
    response.status(404);
    response.send("<h1> 404 : requested page not found on the server </h1>")
});

app.listen(2020, function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now live on localhost:2020 ");
    }
});
