import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "gen"
})
export class GenPipe implements PipeTransform{
    transform(...args){
        // console.log(arguments.length);
        // return args[0].toUpperCase();
        if( args[1] === 'male'){
            return "Mr "+args[0]
        }else{
            return "Miss "+args[0]
        }
    }
}