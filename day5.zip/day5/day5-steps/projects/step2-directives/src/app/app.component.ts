import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <label *ngIf=!showCondition>Show Terms and Conditions : 
    <input type="checkbox" (change)="showCondition = !showCondition">
  </label>
  <div *ngIf=showCondition class="display">
    <h2>Terms and Conditions</h2>
    <hr>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, voluptatum voluptatibus. Molestias est earum, eum quos reiciendis esse. Ea eaque, tempora. Dignissimos blanditiis, quod vel quibusdam id voluptatibus eligendi deserunt.
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, voluptatum voluptatibus. Molestias est earum, eum quos reiciendis esse. Ea eaque, tempora. Dignissimos blanditiis, quod vel quibusdam id voluptatibus eligendi deserunt.
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, voluptatum voluptatibus. Molestias est earum, eum quos reiciendis esse. Ea eaque, tempora. Dignissimos blanditiis, quod vel quibusdam id voluptatibus eligendi deserunt.
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, voluptatum voluptatibus. Molestias est earum, eum quos reiciendis esse. Ea eaque, tempora. Dignissimos blanditiis, quod vel quibusdam id voluptatibus eligendi deserunt.
    </p>
    <label *ngIf=showCondition>Hide Terms and Conditions : 
      <input type="checkbox" (change)="showCondition = !showCondition">
    </label>
  </div>
  <hr>
  <input #powerRange type="range" [value]="power" (change)="power = powerRange.value" min="0" max="10">
  <br>
  <input [(ngModel)]="power" type="range" min="0" max="10">
  {{ power }}
  <div [ngSwitch]="power">
    <p *ngSwitchCase="6">Recovered</p>
    <p *ngSwitchCase="7">Low Power</p>
    <p *ngSwitchCase="8">Strong</p>
    <p *ngSwitchCase="9">Stronger</p>
    <p *ngSwitchCase="10">Unbeatable</p>
    <p *ngSwitchDefault >Needs Rest</p>
  </div>
  <hr>
  <div [ngClass]="stylelist" >
    hello there
  </div>
  <div class="box borderBox" [ngClass]="{ pinkbox : power < 5, orangebox : power > 5 }" >
    hello there
  </div>
  <br>
  <div [ngStyle]="{ 'color': 'yellow', 'background-color' : power > 5 ? 'green' : 'red' }">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat rem, dolorem voluptates nam sint, ducimus consectetur harum praesentium omnis, eligendi soluta aperiam eum autem in? Sed nobis ipsa libero voluptates!
  </div>
  <br>
  <h1 ngNonBindable > {{ welcome to your life }} </h1>
  <br>
  <ol>
    <li>{{ avengers[0] }}</li>
    <li>{{ avengers[1] }}</li>
    <li>{{ avengers[2] }}</li>
  </ol>
  <br>
  <ul>
    <li *ngFor="let hero of avengers; index as idx; first as fst ; last as lst">
    {{ (idx+1)+" "+ hero }}
    <span *ngIf="fst"> ( First Avenger ) </span>
    <span *ngIf="lst"> ( Last Avenger ) </span>
    <span *ngIf="!lst && !fst"> ( Middle Avenger ) </span>
    </li>
  </ul>
  <br>
  <br>
  <br>
  `,
  styles : [`
    .display{
      width : 600px;
      height : 320px;
      background-color : silver;
      padding : 10px;
      font-family : verdana;
      font-size : 14px;
      text-align : justify;
    }
    .box{
      width : 200px;
      height : 200px;
      text-align : center;
      line-height : 200px;
      font-family : arial;
      font-size : 24px;
      font-weight : bold;
    }
    .borderBox{
      border : 10px solid black;
      border-radius : 100px;
    }
    .orangebox{
      background-color : orange;
    }
    .pinkbox{
      background-color : pink;
    }
  `]
})
export class AppComponent {
  title = 'step2-directives';
  stylelist = ['box', 'borderBox', 'orangebox'];
  showCondition = true;
  power  = 7;
  avengers = ['Ironman', 'Hulk', 'Captain America', 'Spiderman', 'Black Widow', 'Scarlet Witch', 'Antman', 'Doctor Strange', 'Captain Marvel']
}

/*
<div [hidden]=showCondition class="display">
*/