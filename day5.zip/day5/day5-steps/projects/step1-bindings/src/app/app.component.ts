import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1>More Bindings</h1>
  <button [disabled]="false" >Click Me</button>
  <br/>
  <input type="button" value="Click Me">
  <br/>
  <h1>{{ title }}</h1>
  <button (click)="showAlert()"> Click to show alert </button>
  <br>
  <button (click)="changeTitle()"> Click to change title </button>
  <br>
  <button (click)="title = 'changed inline'"> Click to change title inline </button>
  <br>
  <button on-click="title = 'changed inline'"> Click to change title inline </button>
  <br>
  <input (keydown.space)="keyfun($event)" type="text">
  <br>
  <input #ip (input)="inputfun(ip.value)" type="range">
  <br>
  <div [style.background-color]="'orange'">
    hello there
  </div>
  <input type="checkbox" (change)="preferRoundedborder = !preferRoundedborder" >
  <div class="box" [class.borderBox]="preferRoundedborder">
    hello there
  </div>

  `,
  styles : [`
  .box{
    background-color : cyan;
    width : 200px;
    height : 200px;
    text-align : center;
    line-height : 200px;
    font-family : arial;
    font-size : 24px;
    font-weight : bold;
  }
  .borderBox{
    border : 10px solid black;
    border-radius : 100px;
  }
  `]
})
export class AppComponent {
  title = 'step1-bindings';
  preferRoundedborder = false;
  showAlert(){
    alert("you clicked me");
  }
  changeTitle(){
    this.title = "Changed";
  }
  keyfun(evt){
    console.log(evt.target.value);
  }
  inputfun(message){
    console.log(message);
  }
}
