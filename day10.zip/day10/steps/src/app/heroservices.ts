import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class HeroService{
    constructor( private http:HttpClient ){}
    getHeros(){
        return this.http.get("http://localhost:4040/data");
    }
    postHero(hero){
        return this.http.post("http://localhost:4040/data", hero);
    }
    getSelectedHero(hero){
        return this.http.get("http://localhost:4040/data/"+hero._id);
    }
    updateHero(hero){
        return this.http.post("http://localhost:4040/data/"+hero._id, hero);
    }
    deleteHero(hero){
        console.log("delete was called");
        return this.http.delete("http://localhost:4040/delete/"+hero._id);
    }
}