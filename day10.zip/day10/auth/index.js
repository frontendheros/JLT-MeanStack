let express = require("express");
let bodyParser = require("body-parser");
let mongoose = require("mongoose");
let session = require("client-sessions");
let bcrypt = require("bcryptjs");

//======================================
let app = express();
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
//======================================
let User = mongoose.model("User", new Schema({
    id : ObjectId,
    firstName : String,
    lastName : String,
    email : { type : String, unique : true},
    password : String
}))

//======================================
app.use(bodyParser.urlencoded({extended : true}));
mongoose.connect("mongodb://localhost/jltuserdb", { useNewUrlParser: true , useUnifiedTopology: true });
app.use(session({
    cookieName : "session",
    secret : "asdfghjkliuytrewwsederty8765aqwertyuik123456lcxswertyukmnbvcxsawerty",
    duration : 30 * 60 * 1000,
    activeDuration : 10 * 60 * 1000
}))
//======================================
app.get("/", function(req, res){
    res.render("index.pug")
})
app.get("/register", function(req, res){
    res.render("register.pug");
})
app.post("/register", function(req, res){
    let hash = bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10));
   let user = new User({
       firstName : req.body.firstName,
       lastName : req.body.lastName,
       email : req.body.email,
       password : hash
   });
   user.save(function(err){
       if(err){
        if(err.code === 11000){
            error = "eMail id is already in use"
        }else{
            error = "something went wrong"
        }
        res.render("register.pug", {
            error : error
        })
       }else{
           res.redirect("/profile")
       }
   })
})
app.get("/login", function(req, res){
    res.render("login.pug")
})
app.post("/login", function(req, res){
   User.findOne({email : req.body.email}, function(error, user){
    if(error){
        res.render("login.pug", {
            error : "No User by that credential"
        })
    }else{
        if(bcrypt.compareSync(req.body.password, user.password)){
            req.session.user = user;
            res.redirect("/profile");
        }else{
            res.render("login.pug", {
                error : "User Name or Password is invalid"
            })
        }
    }
   })
})
app.get("/profile", function(req, res){
    if( req.session && req.session.user ){
        User.findOne({ email : req.session.user.email }, function(error, user){
            if(!user){
                req.session.reset();
                res.redirect("/login");
            }else{
                res.locals.user = user;
                res.render("profile.pug");
            }
        })
    }else{
        res.redirect("/login")
    }
})
app.get("/logout", function(req, res){
    req.session.reset();
    res.redirect("/")
})  
//======================================
app.listen(5050);
console.log("server is now live on localhost:5050")