let express = require("express");
let app = express();

app.get("/", function(res, res){
   res.render("index.pug")
})
app.get("/register", function(res, res){
    res.render("register.pug")
})
app.get("/login", function(res, res){
    res.render("login.pug")
})
app.get("/profile", function(res, res){
    res.render("profile.pug")
})
app.get("/logout", function(res, res){
    res.redirect("/")
})  


app.listen(5050);
console.log("server is now live on localhost:5050")